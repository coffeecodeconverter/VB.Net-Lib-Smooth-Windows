﻿Imports System.ComponentModel

Public Class Form1



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.KeyPreview = True
        ResetUI()
    End Sub

    Private Sub Form1_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        GetFormInfo()
    End Sub

    Private Sub Form1_Move(sender As Object, e As EventArgs) Handles Me.Move
        GetFormInfo()
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        ' Check if Ctrl + Alt + X is pressed
        If e.Control AndAlso e.Alt AndAlso e.KeyCode = Keys.X Then
            ResetUI()
        End If
    End Sub







    Private Sub Button_About_Click(sender As Object, e As EventArgs) Handles Button_About.Click
        MessageBox.Show("Author:        " & vbTab & moduleAuthor & vbCrLf &
                        "Module Name:   " & vbTab & "Smooth" & vbCrLf &
                        "Module Version:" & vbTab & moduleVersion & vbCrLf & vbCrLf &
                        "A module that provides an easy function to move and/or resize a form with smooth animation." & vbCrLf & vbCrLf &
                        "Several other useful functions are also exposed such as getting taskbar position and size.")
    End Sub








    ' Reset Form to Default Size and Position
    Private Sub Button_Reset_Click(sender As Object, e As EventArgs) Handles Button_Reset.Click
        ResetUI()
    End Sub



    Private Sub Button_DisplayInfo_Click(sender As Object, e As EventArgs) Handles Button_DisplayInfo.Click
        ' Usage for Screen Information 
        Dim tempDict As Dictionary(Of String, Dictionary(Of String, Object)) = GetScreenInfo(Me)
        Dim tempString As String = FormatScreenInfo(tempDict)
        MessageBox.Show(tempString)
    End Sub



    Private Sub TextBox_Opacity_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Opacity.TextChanged

    End Sub

    Private Sub TextBox_Opacity_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_Opacity.KeyPress
        ' Allow only digits (0-9)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub


    Private Sub TextBox_Opacity_Validating(sender As Object, e As CancelEventArgs) Handles TextBox_Opacity.Validating
        Try
            If CInt(TextBox_Opacity.Text) = 0 Or CInt(TextBox_Opacity.Text) > 100 Then
                MessageBox.Show("Value must be between 1-100", "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBox_Opacity.Text = "100"
            End If

            SetWindowTransparency(Me, CInt(TextBox_Opacity.Text))

        Catch ex As Exception
            'SUPPRESS
        End Try
    End Sub







    ' BUTTONS
    Private Sub Button_Tiny_Click(sender As Object, e As EventArgs) Handles Button_Tiny.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 150, 150)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 150, 150)"
    End Sub



    Private Sub Button_Smallest_Click(sender As Object, e As EventArgs) Handles Button_Smallest.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 150, 70)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 150, 70)"
    End Sub




    Private Sub Button_DoubleStrip1_Click(sender As Object, e As EventArgs) Handles Button_DoubleStrip1.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, Me.Width, 90)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, Me.Width, 90)"
    End Sub

    Private Sub Button_DoubleStrip2_Click(sender As Object, e As EventArgs) Handles Button_DoubleStrip2.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 300, 90)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 300, 90)"
    End Sub

    Private Sub Button_DoubleStrip3_Click(sender As Object, e As EventArgs) Handles Button_DoubleStrip3.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 600, 90)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 600, 90)"
    End Sub

    Private Sub Button_DoubleStrip4_Click(sender As Object, e As EventArgs) Handles Button_DoubleStrip4.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 800, 90)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 800, 90)"
    End Sub



    Private Sub Button_TripleStrip1_Click(sender As Object, e As EventArgs) Handles Button_TripleStrip1.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, Me.Width, 120)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, Me.Width, 120)"
    End Sub

    Private Sub Button_Quad_Click(sender As Object, e As EventArgs)
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, Me.Width, 150)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, Me.Width, 150)"
    End Sub



    Private Sub Button_Strip1_Click(sender As Object, e As EventArgs) Handles Button_Strip1.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 200, 70)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 200, 70)"
    End Sub


    Private Sub Button_Strip2_Click(sender As Object, e As EventArgs) Handles Button_Strip2.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 400, 70)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 400, 70)"
    End Sub


    Private Sub Button_Strip3_Click(sender As Object, e As EventArgs) Handles Button_Strip3.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 800, 70)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 800, 70)"
    End Sub







    Private Sub Button_Square1_Click(sender As Object, e As EventArgs) Handles Button_Square1.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 250, 250)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 250, 250)"
    End Sub

    Private Sub Button_Square2_Click(sender As Object, e As EventArgs) Handles Button_Square2.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 400, 400)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 400, 400)"
    End Sub

    Private Sub Button_Square3_Click(sender As Object, e As EventArgs) Handles Button_Square3.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 600, 600)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 600, 600)"
    End Sub

    Private Sub Button_Square4_Click(sender As Object, e As EventArgs) Handles Button_Square4.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 800, 800)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 800, 800)"
    End Sub







    Private Sub Button_RectA1_Click(sender As Object, e As EventArgs) Handles Button_RectA1.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 400, 200)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 400, 200)"
    End Sub

    Private Sub Button_RectA2_Click(sender As Object, e As EventArgs) Handles Button_RectA2.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 600, 250)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 600, 250)"
    End Sub

    Private Sub Button_RectA3_Click(sender As Object, e As EventArgs) Handles Button_RectA3.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 800, 300)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 800, 300)"
    End Sub

    Private Sub Button_RectA4_Click(sender As Object, e As EventArgs) Handles Button_RectA4.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 1000, 400)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 1000, 400)"
    End Sub





    Private Sub Button_RectB1_Click(sender As Object, e As EventArgs) Handles Button_RectB1.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 150, 300)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 150, 300)"
    End Sub

    Private Sub Button_RectB2_Click(sender As Object, e As EventArgs) Handles Button_RectB2.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 200, 500)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 200, 500)"
    End Sub

    Private Sub Button_RectB3_Click(sender As Object, e As EventArgs) Handles Button_RectB3.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 300, 500)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 300, 500)"
    End Sub

    Private Sub Button_RectB4_Click(sender As Object, e As EventArgs) Handles Button_RectB4.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 400, 800)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 400, 800)"
    End Sub





    Private Sub Button_Size1_Click(sender As Object, e As EventArgs) Handles Button_Size1.Click
        smooth.MoveWindow(Me, 100, 50, 430, 350)
        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, 100, 50, 430, 350)"
    End Sub

    Private Sub Button_Size2_Click(sender As Object, e As EventArgs) Handles Button_Size2.Click
        smooth.MoveWindow(Me, 150, 100, 550, 430)
        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, 150, 100, 550, 430)"
    End Sub

    Private Sub Button_Size3_Click(sender As Object, e As EventArgs) Handles Button_Size3.Click
        smooth.MoveWindow(Me, 300, 200, 400, 280, 100, 100, 3000)
        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, 300, 200, 400, 280)"
    End Sub

    Private Sub Button_Size4_Click(sender As Object, e As EventArgs) Handles Button_Size4.Click
        smooth.MoveWindow(Me, 400, 300, 500, 400)
        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, 400, 300, 500, 400)"
    End Sub




    Private Sub Button_Fade1_Click(sender As Object, e As EventArgs) Handles Button_Fade1.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 520, 350, 100, 50)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 520, 350, 100, 50)"
    End Sub

    Private Sub Button_Fade2_Click(sender As Object, e As EventArgs) Handles Button_Fade2.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 500, 280, 50, 100)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 500, 280, 50, 100)"
    End Sub

    Private Sub Button_Fade3_Click(sender As Object, e As EventArgs) Handles Button_Fade3.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 400, 250, 1, 100)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 400, 250, 1, 100)"
    End Sub

    Private Sub Button_Fade4_Click(sender As Object, e As EventArgs) Handles Button_Fade4.Click
        Dim currentX As Integer = Me.Location.X
        Dim currentY As Integer = Me.Location.Y
        smooth.MoveWindow(Me, currentX, currentY, 600, 300, 100, 1)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 600, 300, 100, 1)"
    End Sub









    Private Sub Button_TopLeft_Click(sender As Object, e As EventArgs) Handles Button_TopLeft.Click
        Dim currentX As Integer = 0
        Dim currentY As Integer = 0
        smooth.MoveWindow(Me, currentX, currentY, Me.Width, Me.Height)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, Me.Width, Me.Height)"
    End Sub

    Private Sub Button_TopRight_Click(sender As Object, e As EventArgs) Handles Button_TopRight.Click
        Dim currentX As Integer = Screen.PrimaryScreen.Bounds.Width - Me.Width
        Dim currentY As Integer = 0
        smooth.MoveWindow(Me, currentX, currentY, Me.Width, Me.Height)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, Me.Width, Me.Height)"
    End Sub

    Private Sub Button_BottomLeft_Click(sender As Object, e As EventArgs) Handles Button_BottomLeft.Click
        Dim currentX As Integer = 0
        Dim currentY As Integer = Screen.PrimaryScreen.Bounds.Height - Me.Height
        smooth.MoveWindow(Me, currentX, currentY, Me.Width, Me.Height)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, Me.Width, Me.Height)"
    End Sub

    Private Sub Button_BottomRight_Click(sender As Object, e As EventArgs) Handles Button_BottomRight.Click
        Dim currentX As Integer = Screen.PrimaryScreen.Bounds.Width - Me.Width
        Dim currentY As Integer = Screen.PrimaryScreen.Bounds.Height - Me.Height
        smooth.MoveWindow(Me, currentX, currentY, Me.Width, Me.Height)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, Me.Width, Me.Height)"
    End Sub







    Private Sub CheckBox_Animation_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_Animation.CheckedChanged
        If CheckBox_Animation.Checked = True Then
            animationEnabled = True
            TextBox_Interval.Enabled = True
            TextBox_Duration.Enabled = True
            ComboBox_EasingFunctions.Enabled = True

            Label_Interval.Enabled = True
            Label_Duration.Enabled = True
            Label_Easing.Enabled = True
        Else
            animationEnabled = False
            TextBox_Interval.Enabled = False
            TextBox_Duration.Enabled = False
            ComboBox_EasingFunctions.Enabled = False

            Label_Interval.Enabled = False
            Label_Duration.Enabled = False
            Label_Easing.Enabled = False
        End If
    End Sub




    Private Sub ComboBox_EasingFunctions_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_EasingFunctions.SelectedIndexChanged
        Try
            animationEasingFunction = ComboBox_EasingFunctions.SelectedItem.ToString
        Catch ex As Exception
            ' SUPPRESS
        End Try
    End Sub




    Private Sub TextBox_Interval_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Interval.TextChanged
        Try
            animationTimerInterval = CInt(TextBox_Interval.Text)
        Catch ex As Exception
            ' SUPPPRESS
        End Try
    End Sub

    Private Sub TextBox_Interval_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_Interval.KeyPress
        ' Allow only digits (0-9)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub




    Private Sub TextBox_Duration_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Duration.TextChanged
        Try
            animationDuration = CInt(TextBox_Duration.Text)
        Catch ex As Exception
            ' SUPPRESS
        End Try
    End Sub

    Private Sub TextBox_Duration_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_Duration.KeyPress
        ' Allow only digits (0-9)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub




    Private Sub TextBox_CustomX_TextChanged(sender As Object, e As EventArgs) Handles TextBox_CustomX.TextChanged

    End Sub

    Private Sub TextBox_CustomX_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_CustomX.KeyPress
        ' Allow only digits (0-9)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub


    Private Sub TextBox_CustomY_TextChanged(sender As Object, e As EventArgs) Handles TextBox_CustomY.TextChanged

    End Sub

    Private Sub TextBox_CustomY_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_CustomY.KeyPress
        ' Allow only digits (0-9)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub Button_CustomPositionGo_Click(sender As Object, e As EventArgs) Handles Button_CustomPositionGo.Click
        Try
            smooth.MoveWindow(Me, CInt(TextBox_CustomX.Text), CInt(TextBox_CustomY.Text), TextBox_CustomWidth.Text, TextBox_CustomHeight.Text)
            TextBox_VBCode.Text = $"smooth.MoveWindow(Me, {CInt(TextBox_CustomX.Text)}, {CInt(TextBox_CustomY.Text)}, {TextBox_CustomWidth.Text}, {TextBox_CustomHeight.Text})"
        Catch ex As Exception
            ' SUPPRESS
        End Try
    End Sub




    Private Sub TextBox_CustomWidth_TextChanged(sender As Object, e As EventArgs) Handles TextBox_CustomWidth.TextChanged

    End Sub

    Private Sub TextBox_CustomWidth_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_CustomWidth.KeyPress
        ' Allow only digits (0-9)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub


    Private Sub TextBox_CustomHeight_TextChanged(sender As Object, e As EventArgs) Handles TextBox_CustomHeight.TextChanged

    End Sub

    Private Sub TextBox_CustomHeight_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_CustomHeight.KeyPress
        ' Allow only digits (0-9)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub Button_CustomSizeGo_Click(sender As Object, e As EventArgs)
        Try
            smooth.MoveWindow(Me, Me.Location.X, Me.Location.Y, CInt(TextBox_CustomWidth.Text), CInt(TextBox_CustomHeight.Text))
        Catch ex As Exception
            ' SUPPRESS
        End Try
    End Sub





    Private Sub TextBox_Margin_TextChanged(sender As Object, e As EventArgs) Handles TextBox_Margin.TextChanged
        Try
            globalWindowMargin = CInt(TextBox_Margin.Text)
        Catch ex As Exception
            ' SUPPRESS
        End Try
    End Sub


    Private Sub TextBox_Margin_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox_Margin.KeyPress
        ' Allow only digits (0-9)
        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub



    Private Sub Button_Callback_Click(sender As Object, e As EventArgs) Handles Button_Callback.Click

        ' Create a Random object
        Dim rand As New Random()

        ' Define the range
        Dim min As Integer = 400 ' Minimum value (inclusive)
        Dim max As Integer = 800 ' Maximum value (exclusive)

        ' Generate a random integer within the range
        Dim randomX As Integer = rand.Next(min, max)
        Dim randomY As Integer = rand.Next(min, max)
        Dim randomWidth As Integer = rand.Next(min, max)
        Dim randomHeight As Integer = rand.Next(min, max)

        smooth.MoveWindow(Me, randomX, randomY, randomWidth, randomHeight, 100, 100, CInt(TextBox_Duration.Text), "", Sub()
                                                                                                                          testCallBackFunction()
                                                                                                                      End Sub)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 500, 350, 100, 100, Sub() GetScreenInfo() End Sub)"
    End Sub



    Private Sub Button_CallBackWithArgs_Click(sender As Object, e As EventArgs) Handles Button_CallBackWithArgs.Click

        ' Create a Random object
        Dim rand As New Random()

        ' Define the range
        Dim min As Integer = 400 ' Minimum value (inclusive)
        Dim max As Integer = 800 ' Maximum value (exclusive)

        ' Generate a random integer within the range
        Dim randomX As Integer = rand.Next(min, max)
        Dim randomY As Integer = rand.Next(min, max)
        Dim randomWidth As Integer = rand.Next(min, max)
        Dim randomHeight As Integer = rand.Next(min, max)

        smooth.MoveWindow(Me, randomX, randomY, randomWidth, randomHeight, 100, 100, CInt(TextBox_Duration.Text), "", Sub()
                                                                                                                          testCallBackFunctionWithArg("testing")
                                                                                                                      End Sub)

        TextBox_VBCode.Text = $"smooth.MoveWindow(Me, currentX, currentY, 500, 350, 100, 100, Sub() GetScreenInfo() End Sub)"
    End Sub






    Private Sub Button_Random_Click(sender As Object, e As EventArgs) Handles Button_Random.Click
        ' Create a Random object
        Dim rand As New Random()

        ' Define the range
        Dim min As Integer = 400 ' Minimum value (inclusive)
        Dim max As Integer = 800 ' Maximum value (exclusive)

        ' Generate a random integer within the range
        Dim randomX As Integer = rand.Next(min, max)
        Dim randomY As Integer = rand.Next(min, max)
        Dim randomWidth As Integer = rand.Next(min, max)
        Dim randomHeight As Integer = rand.Next(min, max)

        smooth.MoveWindow(Me, randomX, randomY, randomWidth, randomHeight, 100, 100)

    End Sub





    Private Sub Button_Dynamic_Click(sender As Object, e As EventArgs) Handles Button_Dynamic.Click
        CreateDynamicForm()
    End Sub



    ' Chaining window Changes together

    ' NOTE THIS IS AN ASYNC BUTTON
    Private Async Sub Button_Chain1_Click(sender As Object, e As EventArgs) Handles Button_Chain1.Click

        Dim duration As Integer = 1500
        smooth.MoveWindow(Me, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, 150, 800, 1, 100, duration)
        Await Wait(duration)

        duration = 600
        smooth.MoveWindow(Me, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, 150, 70, 100, 100, duration)
        Await Wait(duration)

        duration = 800
        smooth.MoveWindow(Me, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, 600, 150, 100, 100, duration)
        Await Wait(duration)

    End Sub


    ' NOTE THIS IS AN ASYNC BUTTON
    Private Async Sub Button_Chain2_Click(sender As Object, e As EventArgs) Handles Button_Chain2.Click

        Dim duration As Integer = 400
        smooth.MoveWindow(Me, Screen.PrimaryScreen.Bounds.Width, 0, 150, 150, 100, 100, duration, "EaseOutQuart")
        Await Wait(duration)


        duration = 800
        smooth.MoveWindow(Me, Screen.PrimaryScreen.Bounds.Width, 0, 250, 250, 100, 100, duration, "EaseOutQuart")
        Await Wait(duration)


        duration = 800
        smooth.MoveWindow(Me, Screen.PrimaryScreen.Bounds.Width, 0, 400, 400, 100, 100, duration, "EaseOutQuart")
        Await Wait(duration)


        duration = 800
        smooth.MoveWindow(Me, Screen.PrimaryScreen.Bounds.Width, 0, 150, 150, 100, 100, duration, "EaseOutElastic")
        Await Wait(duration)


        duration = 600
        smooth.MoveWindow(Me, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, 150, 150, 100, 100, duration, "EaseOutQuart")
        Await Wait(duration)


        duration = 800
        smooth.MoveWindow(Me, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, 800, 70, 100, 100, duration, "EaseOutElastic")
        Await Wait(duration)

        duration = 800
        smooth.MoveWindow(Me, Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, 800, 800, 100, 100, duration, "EaseOutQuart")
        Await Wait(duration)

    End Sub












    Private Sub ResetUI()
        ComboBox_EasingFunctions.SelectedIndex = 3
        CheckBox_Animation.Checked = True
        TextBox_Interval.Text = "10"
        TextBox_Duration.Text = "800"
        TextBox_CustomX.Text = "50"
        TextBox_CustomY.Text = "50"
        TextBox_CustomWidth.Text = "800"
        TextBox_CustomHeight.Text = "600"
        TextBox_Margin.Text = "10"
        Me.Opacity = 0
        smooth.MoveWindow(Me, 0, 0, 600, 400, 1, 100)
        TextBox_Opacity.Text = "100"
    End Sub



    Private Sub GetFormInfo()
        Label_FormWidth.Text = Me.Width.ToString()
        Label_FormHeight.Text = Me.Height.ToString()
        Label_FormX.Text = Me.Location.X.ToString()
        Label_FormY.Text = Me.Location.Y.ToString()
    End Sub


    Private Sub testCallBackFunction()
        MessageBox.Show("This was called back!")
    End Sub


    Private Sub testCallBackFunctionWithArg(ByVal passedString As String)
        MessageBox.Show("showing the argument value:" & vbCrLf & passedString)
    End Sub


End Class


