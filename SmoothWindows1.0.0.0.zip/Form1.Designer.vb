﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label_FormX = New System.Windows.Forms.Label()
        Me.Label_FormY = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label_FormHeight = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label_FormWidth = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button_Reset = New System.Windows.Forms.Button()
        Me.Button_Smallest = New System.Windows.Forms.Button()
        Me.Button_TopLeft = New System.Windows.Forms.Button()
        Me.Button_TopRight = New System.Windows.Forms.Button()
        Me.Button_BottomLeft = New System.Windows.Forms.Button()
        Me.Button_BottomRight = New System.Windows.Forms.Button()
        Me.Button_Strip1 = New System.Windows.Forms.Button()
        Me.Button_Strip2 = New System.Windows.Forms.Button()
        Me.Button_Strip3 = New System.Windows.Forms.Button()
        Me.Button_Tiny = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button_DisplayInfo = New System.Windows.Forms.Button()
        Me.Button_Square1 = New System.Windows.Forms.Button()
        Me.Button_Square4 = New System.Windows.Forms.Button()
        Me.Button_Square3 = New System.Windows.Forms.Button()
        Me.Button_Square2 = New System.Windows.Forms.Button()
        Me.Button_RectA1 = New System.Windows.Forms.Button()
        Me.Button_RectA4 = New System.Windows.Forms.Button()
        Me.Button_RectA3 = New System.Windows.Forms.Button()
        Me.Button_RectA2 = New System.Windows.Forms.Button()
        Me.Button_RectB1 = New System.Windows.Forms.Button()
        Me.Button_RectB4 = New System.Windows.Forms.Button()
        Me.Button_RectB3 = New System.Windows.Forms.Button()
        Me.Button_RectB2 = New System.Windows.Forms.Button()
        Me.TextBox_CustomX = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox_CustomY = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox_CustomHeight = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox_CustomWidth = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Button_CustomPositionGo = New System.Windows.Forms.Button()
        Me.TextBox_Margin = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CheckBox_Animation = New System.Windows.Forms.CheckBox()
        Me.TextBox_Interval = New System.Windows.Forms.TextBox()
        Me.Label_Interval = New System.Windows.Forms.Label()
        Me.TextBox_Duration = New System.Windows.Forms.TextBox()
        Me.Label_Duration = New System.Windows.Forms.Label()
        Me.ComboBox_EasingFunctions = New System.Windows.Forms.ComboBox()
        Me.Label_Easing = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button_DoubleStrip1 = New System.Windows.Forms.Button()
        Me.Button_DoubleStrip4 = New System.Windows.Forms.Button()
        Me.Button_DoubleStrip3 = New System.Windows.Forms.Button()
        Me.Button_DoubleStrip2 = New System.Windows.Forms.Button()
        Me.Button_TripleStrip1 = New System.Windows.Forms.Button()
        Me.Button_About = New System.Windows.Forms.Button()
        Me.TextBox_Opacity = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Button_Fade1 = New System.Windows.Forms.Button()
        Me.Button_Fade4 = New System.Windows.Forms.Button()
        Me.Button_Fade3 = New System.Windows.Forms.Button()
        Me.Button_Fade2 = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox_VBCode = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Button_Size1 = New System.Windows.Forms.Button()
        Me.Button_Size4 = New System.Windows.Forms.Button()
        Me.Button_Size3 = New System.Windows.Forms.Button()
        Me.Button_Size2 = New System.Windows.Forms.Button()
        Me.Button_Callback = New System.Windows.Forms.Button()
        Me.Button_Random = New System.Windows.Forms.Button()
        Me.Label_Animating = New System.Windows.Forms.Label()
        Me.Button_Dynamic = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(16, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "X:"
        '
        'Label_FormX
        '
        Me.Label_FormX.AutoSize = True
        Me.Label_FormX.Font = New System.Drawing.Font("Calibri", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_FormX.Location = New System.Drawing.Point(19, 4)
        Me.Label_FormX.Name = "Label_FormX"
        Me.Label_FormX.Size = New System.Drawing.Size(30, 11)
        Me.Label_FormX.TabIndex = 3
        Me.Label_FormX.Text = "99999"
        '
        'Label_FormY
        '
        Me.Label_FormY.AutoSize = True
        Me.Label_FormY.Font = New System.Drawing.Font("Calibri", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_FormY.Location = New System.Drawing.Point(64, 4)
        Me.Label_FormY.Name = "Label_FormY"
        Me.Label_FormY.Size = New System.Drawing.Size(30, 11)
        Me.Label_FormY.TabIndex = 5
        Me.Label_FormY.Text = "99999"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(52, 3)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(14, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Y:"
        '
        'Label_FormHeight
        '
        Me.Label_FormHeight.AutoSize = True
        Me.Label_FormHeight.Font = New System.Drawing.Font("Calibri", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_FormHeight.Location = New System.Drawing.Point(64, 17)
        Me.Label_FormHeight.Name = "Label_FormHeight"
        Me.Label_FormHeight.Size = New System.Drawing.Size(30, 11)
        Me.Label_FormHeight.TabIndex = 9
        Me.Label_FormHeight.Text = "99999"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(51, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(17, 13)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "H:"
        '
        'Label_FormWidth
        '
        Me.Label_FormWidth.AutoSize = True
        Me.Label_FormWidth.Font = New System.Drawing.Font("Calibri", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_FormWidth.Location = New System.Drawing.Point(19, 17)
        Me.Label_FormWidth.Name = "Label_FormWidth"
        Me.Label_FormWidth.Size = New System.Drawing.Size(30, 11)
        Me.Label_FormWidth.TabIndex = 7
        Me.Label_FormWidth.Text = "99999"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(2, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(20, 13)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "W:"
        '
        'Button_Reset
        '
        Me.Button_Reset.BackColor = System.Drawing.Color.IndianRed
        Me.Button_Reset.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Reset.ForeColor = System.Drawing.Color.White
        Me.Button_Reset.Location = New System.Drawing.Point(2, 2)
        Me.Button_Reset.Name = "Button_Reset"
        Me.Button_Reset.Size = New System.Drawing.Size(59, 23)
        Me.Button_Reset.TabIndex = 10
        Me.Button_Reset.Text = "Reset"
        Me.Button_Reset.UseVisualStyleBackColor = False
        '
        'Button_Smallest
        '
        Me.Button_Smallest.BackColor = System.Drawing.Color.Transparent
        Me.Button_Smallest.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Smallest.ForeColor = System.Drawing.Color.Black
        Me.Button_Smallest.Location = New System.Drawing.Point(297, 2)
        Me.Button_Smallest.Name = "Button_Smallest"
        Me.Button_Smallest.Size = New System.Drawing.Size(59, 23)
        Me.Button_Smallest.TabIndex = 11
        Me.Button_Smallest.Text = "Smallest"
        Me.Button_Smallest.UseVisualStyleBackColor = False
        '
        'Button_TopLeft
        '
        Me.Button_TopLeft.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_TopLeft.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_TopLeft.Location = New System.Drawing.Point(746, 384)
        Me.Button_TopLeft.Name = "Button_TopLeft"
        Me.Button_TopLeft.Size = New System.Drawing.Size(26, 32)
        Me.Button_TopLeft.TabIndex = 12
        Me.Button_TopLeft.Text = "↖"
        Me.Button_TopLeft.UseVisualStyleBackColor = True
        '
        'Button_TopRight
        '
        Me.Button_TopRight.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_TopRight.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_TopRight.Location = New System.Drawing.Point(772, 384)
        Me.Button_TopRight.Name = "Button_TopRight"
        Me.Button_TopRight.Size = New System.Drawing.Size(26, 32)
        Me.Button_TopRight.TabIndex = 13
        Me.Button_TopRight.Text = "↗"
        Me.Button_TopRight.UseVisualStyleBackColor = True
        '
        'Button_BottomLeft
        '
        Me.Button_BottomLeft.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_BottomLeft.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_BottomLeft.Location = New System.Drawing.Point(746, 416)
        Me.Button_BottomLeft.Name = "Button_BottomLeft"
        Me.Button_BottomLeft.Size = New System.Drawing.Size(26, 32)
        Me.Button_BottomLeft.TabIndex = 14
        Me.Button_BottomLeft.Text = "↙"
        Me.Button_BottomLeft.UseVisualStyleBackColor = True
        '
        'Button_BottomRight
        '
        Me.Button_BottomRight.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_BottomRight.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_BottomRight.Location = New System.Drawing.Point(772, 416)
        Me.Button_BottomRight.Name = "Button_BottomRight"
        Me.Button_BottomRight.Size = New System.Drawing.Size(26, 32)
        Me.Button_BottomRight.TabIndex = 15
        Me.Button_BottomRight.Text = "↘"
        Me.Button_BottomRight.UseVisualStyleBackColor = True
        '
        'Button_Strip1
        '
        Me.Button_Strip1.BackColor = System.Drawing.Color.Transparent
        Me.Button_Strip1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Strip1.ForeColor = System.Drawing.Color.Black
        Me.Button_Strip1.Location = New System.Drawing.Point(61, 2)
        Me.Button_Strip1.Name = "Button_Strip1"
        Me.Button_Strip1.Size = New System.Drawing.Size(59, 23)
        Me.Button_Strip1.TabIndex = 27
        Me.Button_Strip1.Text = "Strip 1"
        Me.Button_Strip1.UseVisualStyleBackColor = False
        '
        'Button_Strip2
        '
        Me.Button_Strip2.BackColor = System.Drawing.Color.Transparent
        Me.Button_Strip2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Strip2.ForeColor = System.Drawing.Color.Black
        Me.Button_Strip2.Location = New System.Drawing.Point(120, 2)
        Me.Button_Strip2.Name = "Button_Strip2"
        Me.Button_Strip2.Size = New System.Drawing.Size(59, 23)
        Me.Button_Strip2.TabIndex = 28
        Me.Button_Strip2.Text = "Strip 2"
        Me.Button_Strip2.UseVisualStyleBackColor = False
        '
        'Button_Strip3
        '
        Me.Button_Strip3.BackColor = System.Drawing.Color.Transparent
        Me.Button_Strip3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Strip3.ForeColor = System.Drawing.Color.Black
        Me.Button_Strip3.Location = New System.Drawing.Point(179, 2)
        Me.Button_Strip3.Name = "Button_Strip3"
        Me.Button_Strip3.Size = New System.Drawing.Size(59, 23)
        Me.Button_Strip3.TabIndex = 29
        Me.Button_Strip3.Text = "Strip 3"
        Me.Button_Strip3.UseVisualStyleBackColor = False
        '
        'Button_Tiny
        '
        Me.Button_Tiny.BackColor = System.Drawing.Color.Transparent
        Me.Button_Tiny.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Tiny.ForeColor = System.Drawing.Color.Black
        Me.Button_Tiny.Location = New System.Drawing.Point(238, 2)
        Me.Button_Tiny.Name = "Button_Tiny"
        Me.Button_Tiny.Size = New System.Drawing.Size(59, 23)
        Me.Button_Tiny.TabIndex = 30
        Me.Button_Tiny.Text = "Tiny"
        Me.Button_Tiny.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Button_DisplayInfo)
        Me.Panel1.Controls.Add(Me.Label_FormX)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label_FormY)
        Me.Panel1.Controls.Add(Me.Label_FormWidth)
        Me.Panel1.Controls.Add(Me.Label_FormHeight)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Location = New System.Drawing.Point(4, 48)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(116, 33)
        Me.Panel1.TabIndex = 31
        '
        'Button_DisplayInfo
        '
        Me.Button_DisplayInfo.BackColor = System.Drawing.Color.DeepSkyBlue
        Me.Button_DisplayInfo.Font = New System.Drawing.Font("Century", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_DisplayInfo.ForeColor = System.Drawing.Color.White
        Me.Button_DisplayInfo.Location = New System.Drawing.Point(97, 4)
        Me.Button_DisplayInfo.Name = "Button_DisplayInfo"
        Me.Button_DisplayInfo.Size = New System.Drawing.Size(19, 23)
        Me.Button_DisplayInfo.TabIndex = 36
        Me.Button_DisplayInfo.Text = "i"
        Me.Button_DisplayInfo.UseVisualStyleBackColor = False
        '
        'Button_Square1
        '
        Me.Button_Square1.BackColor = System.Drawing.Color.Transparent
        Me.Button_Square1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Square1.ForeColor = System.Drawing.Color.Black
        Me.Button_Square1.Location = New System.Drawing.Point(2, 81)
        Me.Button_Square1.Name = "Button_Square1"
        Me.Button_Square1.Size = New System.Drawing.Size(59, 23)
        Me.Button_Square1.TabIndex = 32
        Me.Button_Square1.Text = "Square 1"
        Me.Button_Square1.UseVisualStyleBackColor = False
        '
        'Button_Square4
        '
        Me.Button_Square4.BackColor = System.Drawing.Color.Transparent
        Me.Button_Square4.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Square4.ForeColor = System.Drawing.Color.Black
        Me.Button_Square4.Location = New System.Drawing.Point(61, 104)
        Me.Button_Square4.Name = "Button_Square4"
        Me.Button_Square4.Size = New System.Drawing.Size(59, 23)
        Me.Button_Square4.TabIndex = 35
        Me.Button_Square4.Text = "Square 4"
        Me.Button_Square4.UseVisualStyleBackColor = False
        '
        'Button_Square3
        '
        Me.Button_Square3.BackColor = System.Drawing.Color.Transparent
        Me.Button_Square3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Square3.ForeColor = System.Drawing.Color.Black
        Me.Button_Square3.Location = New System.Drawing.Point(2, 104)
        Me.Button_Square3.Name = "Button_Square3"
        Me.Button_Square3.Size = New System.Drawing.Size(59, 23)
        Me.Button_Square3.TabIndex = 34
        Me.Button_Square3.Text = "Square 3"
        Me.Button_Square3.UseVisualStyleBackColor = False
        '
        'Button_Square2
        '
        Me.Button_Square2.BackColor = System.Drawing.Color.Transparent
        Me.Button_Square2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Square2.ForeColor = System.Drawing.Color.Black
        Me.Button_Square2.Location = New System.Drawing.Point(61, 81)
        Me.Button_Square2.Name = "Button_Square2"
        Me.Button_Square2.Size = New System.Drawing.Size(59, 23)
        Me.Button_Square2.TabIndex = 33
        Me.Button_Square2.Text = "Square 2"
        Me.Button_Square2.UseVisualStyleBackColor = False
        '
        'Button_RectA1
        '
        Me.Button_RectA1.BackColor = System.Drawing.Color.Transparent
        Me.Button_RectA1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_RectA1.ForeColor = System.Drawing.Color.Black
        Me.Button_RectA1.Location = New System.Drawing.Point(2, 133)
        Me.Button_RectA1.Name = "Button_RectA1"
        Me.Button_RectA1.Size = New System.Drawing.Size(59, 23)
        Me.Button_RectA1.TabIndex = 36
        Me.Button_RectA1.Text = "Rect A1"
        Me.Button_RectA1.UseVisualStyleBackColor = False
        '
        'Button_RectA4
        '
        Me.Button_RectA4.BackColor = System.Drawing.Color.Transparent
        Me.Button_RectA4.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_RectA4.ForeColor = System.Drawing.Color.Black
        Me.Button_RectA4.Location = New System.Drawing.Point(61, 156)
        Me.Button_RectA4.Name = "Button_RectA4"
        Me.Button_RectA4.Size = New System.Drawing.Size(59, 23)
        Me.Button_RectA4.TabIndex = 39
        Me.Button_RectA4.Text = "Rect A4"
        Me.Button_RectA4.UseVisualStyleBackColor = False
        '
        'Button_RectA3
        '
        Me.Button_RectA3.BackColor = System.Drawing.Color.Transparent
        Me.Button_RectA3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_RectA3.ForeColor = System.Drawing.Color.Black
        Me.Button_RectA3.Location = New System.Drawing.Point(2, 156)
        Me.Button_RectA3.Name = "Button_RectA3"
        Me.Button_RectA3.Size = New System.Drawing.Size(59, 23)
        Me.Button_RectA3.TabIndex = 38
        Me.Button_RectA3.Text = "Rect A3"
        Me.Button_RectA3.UseVisualStyleBackColor = False
        '
        'Button_RectA2
        '
        Me.Button_RectA2.BackColor = System.Drawing.Color.Transparent
        Me.Button_RectA2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_RectA2.ForeColor = System.Drawing.Color.Black
        Me.Button_RectA2.Location = New System.Drawing.Point(61, 133)
        Me.Button_RectA2.Name = "Button_RectA2"
        Me.Button_RectA2.Size = New System.Drawing.Size(59, 23)
        Me.Button_RectA2.TabIndex = 37
        Me.Button_RectA2.Text = "Rect A2"
        Me.Button_RectA2.UseVisualStyleBackColor = False
        '
        'Button_RectB1
        '
        Me.Button_RectB1.BackColor = System.Drawing.Color.Transparent
        Me.Button_RectB1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_RectB1.ForeColor = System.Drawing.Color.Black
        Me.Button_RectB1.Location = New System.Drawing.Point(2, 187)
        Me.Button_RectB1.Name = "Button_RectB1"
        Me.Button_RectB1.Size = New System.Drawing.Size(59, 23)
        Me.Button_RectB1.TabIndex = 40
        Me.Button_RectB1.Text = "Rect B1"
        Me.Button_RectB1.UseVisualStyleBackColor = False
        '
        'Button_RectB4
        '
        Me.Button_RectB4.BackColor = System.Drawing.Color.Transparent
        Me.Button_RectB4.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_RectB4.ForeColor = System.Drawing.Color.Black
        Me.Button_RectB4.Location = New System.Drawing.Point(61, 210)
        Me.Button_RectB4.Name = "Button_RectB4"
        Me.Button_RectB4.Size = New System.Drawing.Size(59, 23)
        Me.Button_RectB4.TabIndex = 43
        Me.Button_RectB4.Text = "Rect B4"
        Me.Button_RectB4.UseVisualStyleBackColor = False
        '
        'Button_RectB3
        '
        Me.Button_RectB3.BackColor = System.Drawing.Color.Transparent
        Me.Button_RectB3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_RectB3.ForeColor = System.Drawing.Color.Black
        Me.Button_RectB3.Location = New System.Drawing.Point(2, 210)
        Me.Button_RectB3.Name = "Button_RectB3"
        Me.Button_RectB3.Size = New System.Drawing.Size(59, 23)
        Me.Button_RectB3.TabIndex = 42
        Me.Button_RectB3.Text = "Rect B3"
        Me.Button_RectB3.UseVisualStyleBackColor = False
        '
        'Button_RectB2
        '
        Me.Button_RectB2.BackColor = System.Drawing.Color.Transparent
        Me.Button_RectB2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_RectB2.ForeColor = System.Drawing.Color.Black
        Me.Button_RectB2.Location = New System.Drawing.Point(61, 187)
        Me.Button_RectB2.Name = "Button_RectB2"
        Me.Button_RectB2.Size = New System.Drawing.Size(59, 23)
        Me.Button_RectB2.TabIndex = 41
        Me.Button_RectB2.Text = "Rect B2"
        Me.Button_RectB2.UseVisualStyleBackColor = False
        '
        'TextBox_CustomX
        '
        Me.TextBox_CustomX.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_CustomX.Location = New System.Drawing.Point(135, 166)
        Me.TextBox_CustomX.Name = "TextBox_CustomX"
        Me.TextBox_CustomX.Size = New System.Drawing.Size(30, 18)
        Me.TextBox_CustomX.TabIndex = 44
        Me.TextBox_CustomX.Text = "50"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(120, 169)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(16, 13)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "X:"
        '
        'TextBox_CustomY
        '
        Me.TextBox_CustomY.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_CustomY.Location = New System.Drawing.Point(178, 166)
        Me.TextBox_CustomY.Name = "TextBox_CustomY"
        Me.TextBox_CustomY.Size = New System.Drawing.Size(30, 18)
        Me.TextBox_CustomY.TabIndex = 46
        Me.TextBox_CustomY.Text = "50"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(164, 169)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(14, 13)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "Y:"
        '
        'TextBox_CustomHeight
        '
        Me.TextBox_CustomHeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_CustomHeight.Location = New System.Drawing.Point(178, 189)
        Me.TextBox_CustomHeight.Name = "TextBox_CustomHeight"
        Me.TextBox_CustomHeight.Size = New System.Drawing.Size(30, 18)
        Me.TextBox_CustomHeight.TabIndex = 50
        Me.TextBox_CustomHeight.Text = "600"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(164, 192)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(17, 13)
        Me.Label5.TabIndex = 49
        Me.Label5.Text = "H:"
        '
        'TextBox_CustomWidth
        '
        Me.TextBox_CustomWidth.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_CustomWidth.Location = New System.Drawing.Point(135, 189)
        Me.TextBox_CustomWidth.Name = "TextBox_CustomWidth"
        Me.TextBox_CustomWidth.Size = New System.Drawing.Size(30, 18)
        Me.TextBox_CustomWidth.TabIndex = 48
        Me.TextBox_CustomWidth.Text = "800"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(120, 192)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(20, 13)
        Me.Label7.TabIndex = 47
        Me.Label7.Text = "W:"
        '
        'Button_CustomPositionGo
        '
        Me.Button_CustomPositionGo.BackColor = System.Drawing.Color.LimeGreen
        Me.Button_CustomPositionGo.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_CustomPositionGo.ForeColor = System.Drawing.Color.White
        Me.Button_CustomPositionGo.Location = New System.Drawing.Point(210, 177)
        Me.Button_CustomPositionGo.Name = "Button_CustomPositionGo"
        Me.Button_CustomPositionGo.Size = New System.Drawing.Size(28, 23)
        Me.Button_CustomPositionGo.TabIndex = 51
        Me.Button_CustomPositionGo.Text = "Go"
        Me.Button_CustomPositionGo.UseVisualStyleBackColor = False
        '
        'TextBox_Margin
        '
        Me.TextBox_Margin.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_Margin.Location = New System.Drawing.Point(178, 215)
        Me.TextBox_Margin.Name = "TextBox_Margin"
        Me.TextBox_Margin.Size = New System.Drawing.Size(30, 18)
        Me.TextBox_Margin.TabIndex = 54
        Me.TextBox_Margin.Text = "10"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(136, 217)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(43, 13)
        Me.Label9.TabIndex = 53
        Me.Label9.Text = "Margin:"
        '
        'CheckBox_Animation
        '
        Me.CheckBox_Animation.AutoSize = True
        Me.CheckBox_Animation.Checked = True
        Me.CheckBox_Animation.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_Animation.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_Animation.Location = New System.Drawing.Point(4, 6)
        Me.CheckBox_Animation.Name = "CheckBox_Animation"
        Me.CheckBox_Animation.Size = New System.Drawing.Size(66, 17)
        Me.CheckBox_Animation.TabIndex = 55
        Me.CheckBox_Animation.Text = "Animate"
        Me.CheckBox_Animation.UseVisualStyleBackColor = True
        '
        'TextBox_Interval
        '
        Me.TextBox_Interval.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_Interval.Location = New System.Drawing.Point(56, 27)
        Me.TextBox_Interval.Name = "TextBox_Interval"
        Me.TextBox_Interval.Size = New System.Drawing.Size(33, 18)
        Me.TextBox_Interval.TabIndex = 57
        Me.TextBox_Interval.Text = "10"
        '
        'Label_Interval
        '
        Me.Label_Interval.AutoSize = True
        Me.Label_Interval.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Interval.Location = New System.Drawing.Point(0, 30)
        Me.Label_Interval.Name = "Label_Interval"
        Me.Label_Interval.Size = New System.Drawing.Size(47, 13)
        Me.Label_Interval.TabIndex = 56
        Me.Label_Interval.Text = "Interval:"
        '
        'TextBox_Duration
        '
        Me.TextBox_Duration.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_Duration.Location = New System.Drawing.Point(56, 46)
        Me.TextBox_Duration.Name = "TextBox_Duration"
        Me.TextBox_Duration.Size = New System.Drawing.Size(33, 18)
        Me.TextBox_Duration.TabIndex = 59
        Me.TextBox_Duration.Text = "400"
        '
        'Label_Duration
        '
        Me.Label_Duration.AutoSize = True
        Me.Label_Duration.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Duration.Location = New System.Drawing.Point(0, 49)
        Me.Label_Duration.Name = "Label_Duration"
        Me.Label_Duration.Size = New System.Drawing.Size(51, 13)
        Me.Label_Duration.TabIndex = 58
        Me.Label_Duration.Text = "Duration:"
        '
        'ComboBox_EasingFunctions
        '
        Me.ComboBox_EasingFunctions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_EasingFunctions.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox_EasingFunctions.FormattingEnabled = True
        Me.ComboBox_EasingFunctions.Items.AddRange(New Object() {"EaseInOutSin", "EaseOutCubic", "EaseOutQuad", "EaseOutQuart"})
        Me.ComboBox_EasingFunctions.Location = New System.Drawing.Point(1, 87)
        Me.ComboBox_EasingFunctions.Name = "ComboBox_EasingFunctions"
        Me.ComboBox_EasingFunctions.Size = New System.Drawing.Size(106, 21)
        Me.ComboBox_EasingFunctions.TabIndex = 60
        '
        'Label_Easing
        '
        Me.Label_Easing.AutoSize = True
        Me.Label_Easing.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Easing.Location = New System.Drawing.Point(1, 71)
        Me.Label_Easing.Name = "Label_Easing"
        Me.Label_Easing.Size = New System.Drawing.Size(40, 13)
        Me.Label_Easing.TabIndex = 61
        Me.Label_Easing.Text = "Easing:"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Label_Animating)
        Me.Panel2.Controls.Add(Me.Label_Interval)
        Me.Panel2.Controls.Add(Me.TextBox_Interval)
        Me.Panel2.Controls.Add(Me.Label_Duration)
        Me.Panel2.Controls.Add(Me.CheckBox_Animation)
        Me.Panel2.Controls.Add(Me.TextBox_Duration)
        Me.Panel2.Controls.Add(Me.ComboBox_EasingFunctions)
        Me.Panel2.Controls.Add(Me.Label_Easing)
        Me.Panel2.Location = New System.Drawing.Point(123, 48)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(115, 110)
        Me.Panel2.TabIndex = 62
        '
        'Button_DoubleStrip1
        '
        Me.Button_DoubleStrip1.BackColor = System.Drawing.Color.Transparent
        Me.Button_DoubleStrip1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_DoubleStrip1.ForeColor = System.Drawing.Color.Black
        Me.Button_DoubleStrip1.Location = New System.Drawing.Point(61, 25)
        Me.Button_DoubleStrip1.Name = "Button_DoubleStrip1"
        Me.Button_DoubleStrip1.Size = New System.Drawing.Size(59, 23)
        Me.Button_DoubleStrip1.TabIndex = 63
        Me.Button_DoubleStrip1.Text = "Double 1"
        Me.Button_DoubleStrip1.UseVisualStyleBackColor = False
        '
        'Button_DoubleStrip4
        '
        Me.Button_DoubleStrip4.BackColor = System.Drawing.Color.Transparent
        Me.Button_DoubleStrip4.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_DoubleStrip4.ForeColor = System.Drawing.Color.Black
        Me.Button_DoubleStrip4.Location = New System.Drawing.Point(238, 25)
        Me.Button_DoubleStrip4.Name = "Button_DoubleStrip4"
        Me.Button_DoubleStrip4.Size = New System.Drawing.Size(59, 23)
        Me.Button_DoubleStrip4.TabIndex = 66
        Me.Button_DoubleStrip4.Text = "Double 4"
        Me.Button_DoubleStrip4.UseVisualStyleBackColor = False
        '
        'Button_DoubleStrip3
        '
        Me.Button_DoubleStrip3.BackColor = System.Drawing.Color.Transparent
        Me.Button_DoubleStrip3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_DoubleStrip3.ForeColor = System.Drawing.Color.Black
        Me.Button_DoubleStrip3.Location = New System.Drawing.Point(179, 25)
        Me.Button_DoubleStrip3.Name = "Button_DoubleStrip3"
        Me.Button_DoubleStrip3.Size = New System.Drawing.Size(59, 23)
        Me.Button_DoubleStrip3.TabIndex = 65
        Me.Button_DoubleStrip3.Text = "Double 3"
        Me.Button_DoubleStrip3.UseVisualStyleBackColor = False
        '
        'Button_DoubleStrip2
        '
        Me.Button_DoubleStrip2.BackColor = System.Drawing.Color.Transparent
        Me.Button_DoubleStrip2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_DoubleStrip2.ForeColor = System.Drawing.Color.Black
        Me.Button_DoubleStrip2.Location = New System.Drawing.Point(120, 25)
        Me.Button_DoubleStrip2.Name = "Button_DoubleStrip2"
        Me.Button_DoubleStrip2.Size = New System.Drawing.Size(59, 23)
        Me.Button_DoubleStrip2.TabIndex = 64
        Me.Button_DoubleStrip2.Text = "Double 2"
        Me.Button_DoubleStrip2.UseVisualStyleBackColor = False
        '
        'Button_TripleStrip1
        '
        Me.Button_TripleStrip1.BackColor = System.Drawing.Color.Transparent
        Me.Button_TripleStrip1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_TripleStrip1.ForeColor = System.Drawing.Color.Black
        Me.Button_TripleStrip1.Location = New System.Drawing.Point(297, 25)
        Me.Button_TripleStrip1.Name = "Button_TripleStrip1"
        Me.Button_TripleStrip1.Size = New System.Drawing.Size(59, 23)
        Me.Button_TripleStrip1.TabIndex = 67
        Me.Button_TripleStrip1.Text = "Triple"
        Me.Button_TripleStrip1.UseVisualStyleBackColor = False
        '
        'Button_About
        '
        Me.Button_About.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button_About.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_About.ForeColor = System.Drawing.Color.White
        Me.Button_About.Location = New System.Drawing.Point(296, 209)
        Me.Button_About.Name = "Button_About"
        Me.Button_About.Size = New System.Drawing.Size(59, 23)
        Me.Button_About.TabIndex = 69
        Me.Button_About.Text = "About"
        Me.Button_About.UseVisualStyleBackColor = False
        '
        'TextBox_Opacity
        '
        Me.TextBox_Opacity.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_Opacity.Location = New System.Drawing.Point(325, 182)
        Me.TextBox_Opacity.Name = "TextBox_Opacity"
        Me.TextBox_Opacity.Size = New System.Drawing.Size(30, 18)
        Me.TextBox_Opacity.TabIndex = 71
        Me.TextBox_Opacity.Text = "100"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(280, 184)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(46, 13)
        Me.Label10.TabIndex = 70
        Me.Label10.Text = "Opacity:"
        '
        'Button_Fade1
        '
        Me.Button_Fade1.BackColor = System.Drawing.Color.Transparent
        Me.Button_Fade1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Fade1.ForeColor = System.Drawing.Color.Black
        Me.Button_Fade1.Location = New System.Drawing.Point(238, 133)
        Me.Button_Fade1.Name = "Button_Fade1"
        Me.Button_Fade1.Size = New System.Drawing.Size(59, 23)
        Me.Button_Fade1.TabIndex = 72
        Me.Button_Fade1.Text = "Fade 1"
        Me.Button_Fade1.UseVisualStyleBackColor = False
        '
        'Button_Fade4
        '
        Me.Button_Fade4.BackColor = System.Drawing.Color.Transparent
        Me.Button_Fade4.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Fade4.ForeColor = System.Drawing.Color.Black
        Me.Button_Fade4.Location = New System.Drawing.Point(297, 156)
        Me.Button_Fade4.Name = "Button_Fade4"
        Me.Button_Fade4.Size = New System.Drawing.Size(59, 23)
        Me.Button_Fade4.TabIndex = 75
        Me.Button_Fade4.Text = "Fade 4"
        Me.Button_Fade4.UseVisualStyleBackColor = False
        '
        'Button_Fade3
        '
        Me.Button_Fade3.BackColor = System.Drawing.Color.Transparent
        Me.Button_Fade3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Fade3.ForeColor = System.Drawing.Color.Black
        Me.Button_Fade3.Location = New System.Drawing.Point(238, 156)
        Me.Button_Fade3.Name = "Button_Fade3"
        Me.Button_Fade3.Size = New System.Drawing.Size(59, 23)
        Me.Button_Fade3.TabIndex = 74
        Me.Button_Fade3.Text = "Fade 3"
        Me.Button_Fade3.UseVisualStyleBackColor = False
        '
        'Button_Fade2
        '
        Me.Button_Fade2.BackColor = System.Drawing.Color.Transparent
        Me.Button_Fade2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Fade2.ForeColor = System.Drawing.Color.Black
        Me.Button_Fade2.Location = New System.Drawing.Point(297, 133)
        Me.Button_Fade2.Name = "Button_Fade2"
        Me.Button_Fade2.Size = New System.Drawing.Size(59, 23)
        Me.Button_Fade2.TabIndex = 73
        Me.Button_Fade2.Text = "Fade 2"
        Me.Button_Fade2.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Red
        Me.Label11.Location = New System.Drawing.Point(246, 117)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(102, 13)
        Me.Label11.TabIndex = 76
        Me.Label11.Text = "Ctrl + Alt + X to Reset"
        '
        'TextBox_VBCode
        '
        Me.TextBox_VBCode.Location = New System.Drawing.Point(57, 237)
        Me.TextBox_VBCode.Name = "TextBox_VBCode"
        Me.TextBox_VBCode.ReadOnly = True
        Me.TextBox_VBCode.Size = New System.Drawing.Size(298, 20)
        Me.TextBox_VBCode.TabIndex = 77
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(5, 240)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 13)
        Me.Label12.TabIndex = 78
        Me.Label12.Text = "VB.Code"
        '
        'Button_Size1
        '
        Me.Button_Size1.BackColor = System.Drawing.Color.Transparent
        Me.Button_Size1.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Size1.ForeColor = System.Drawing.Color.Black
        Me.Button_Size1.Location = New System.Drawing.Point(238, 48)
        Me.Button_Size1.Name = "Button_Size1"
        Me.Button_Size1.Size = New System.Drawing.Size(59, 23)
        Me.Button_Size1.TabIndex = 79
        Me.Button_Size1.Text = "Size 1"
        Me.Button_Size1.UseVisualStyleBackColor = False
        '
        'Button_Size4
        '
        Me.Button_Size4.BackColor = System.Drawing.Color.Transparent
        Me.Button_Size4.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Size4.ForeColor = System.Drawing.Color.Black
        Me.Button_Size4.Location = New System.Drawing.Point(297, 71)
        Me.Button_Size4.Name = "Button_Size4"
        Me.Button_Size4.Size = New System.Drawing.Size(59, 23)
        Me.Button_Size4.TabIndex = 82
        Me.Button_Size4.Text = "Size 4"
        Me.Button_Size4.UseVisualStyleBackColor = False
        '
        'Button_Size3
        '
        Me.Button_Size3.BackColor = System.Drawing.Color.Transparent
        Me.Button_Size3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Size3.ForeColor = System.Drawing.Color.Black
        Me.Button_Size3.Location = New System.Drawing.Point(238, 71)
        Me.Button_Size3.Name = "Button_Size3"
        Me.Button_Size3.Size = New System.Drawing.Size(59, 23)
        Me.Button_Size3.TabIndex = 81
        Me.Button_Size3.Text = "Size 3"
        Me.Button_Size3.UseVisualStyleBackColor = False
        '
        'Button_Size2
        '
        Me.Button_Size2.BackColor = System.Drawing.Color.Transparent
        Me.Button_Size2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Size2.ForeColor = System.Drawing.Color.Black
        Me.Button_Size2.Location = New System.Drawing.Point(297, 48)
        Me.Button_Size2.Name = "Button_Size2"
        Me.Button_Size2.Size = New System.Drawing.Size(59, 23)
        Me.Button_Size2.TabIndex = 80
        Me.Button_Size2.Text = "Size 2"
        Me.Button_Size2.UseVisualStyleBackColor = False
        '
        'Button_Callback
        '
        Me.Button_Callback.BackColor = System.Drawing.Color.Transparent
        Me.Button_Callback.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Callback.ForeColor = System.Drawing.Color.Black
        Me.Button_Callback.Location = New System.Drawing.Point(238, 209)
        Me.Button_Callback.Name = "Button_Callback"
        Me.Button_Callback.Size = New System.Drawing.Size(59, 23)
        Me.Button_Callback.TabIndex = 83
        Me.Button_Callback.Text = "CallBack"
        Me.Button_Callback.UseVisualStyleBackColor = False
        '
        'Button_Random
        '
        Me.Button_Random.BackColor = System.Drawing.Color.DarkViolet
        Me.Button_Random.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Random.ForeColor = System.Drawing.Color.White
        Me.Button_Random.Location = New System.Drawing.Point(2, 25)
        Me.Button_Random.Name = "Button_Random"
        Me.Button_Random.Size = New System.Drawing.Size(59, 23)
        Me.Button_Random.TabIndex = 84
        Me.Button_Random.Text = "Random"
        Me.Button_Random.UseVisualStyleBackColor = False
        '
        'Label_Animating
        '
        Me.Label_Animating.AutoSize = True
        Me.Label_Animating.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_Animating.Location = New System.Drawing.Point(68, 7)
        Me.Label_Animating.Name = "Label_Animating"
        Me.Label_Animating.Size = New System.Drawing.Size(46, 13)
        Me.Label_Animating.TabIndex = 62
        Me.Label_Animating.Text = "Stopped"
        '
        'Button_Dynamic
        '
        Me.Button_Dynamic.BackColor = System.Drawing.Color.Transparent
        Me.Button_Dynamic.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Dynamic.ForeColor = System.Drawing.Color.Black
        Me.Button_Dynamic.Location = New System.Drawing.Point(297, 94)
        Me.Button_Dynamic.Name = "Button_Dynamic"
        Me.Button_Dynamic.Size = New System.Drawing.Size(59, 23)
        Me.Button_Dynamic.TabIndex = 85
        Me.Button_Dynamic.Text = "Dynamic"
        Me.Button_Dynamic.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button_Dynamic)
        Me.Controls.Add(Me.Button_Random)
        Me.Controls.Add(Me.Button_Callback)
        Me.Controls.Add(Me.Button_Reset)
        Me.Controls.Add(Me.Button_Size1)
        Me.Controls.Add(Me.Button_Size4)
        Me.Controls.Add(Me.Button_Size3)
        Me.Controls.Add(Me.Button_Size2)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.TextBox_VBCode)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Button_Fade1)
        Me.Controls.Add(Me.Button_Fade4)
        Me.Controls.Add(Me.Button_Fade3)
        Me.Controls.Add(Me.Button_Fade2)
        Me.Controls.Add(Me.TextBox_Opacity)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Button_About)
        Me.Controls.Add(Me.Button_TripleStrip1)
        Me.Controls.Add(Me.Button_DoubleStrip1)
        Me.Controls.Add(Me.Button_DoubleStrip4)
        Me.Controls.Add(Me.Button_DoubleStrip3)
        Me.Controls.Add(Me.Button_DoubleStrip2)
        Me.Controls.Add(Me.TextBox_Margin)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Button_CustomPositionGo)
        Me.Controls.Add(Me.TextBox_CustomHeight)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TextBox_CustomWidth)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TextBox_CustomY)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox_CustomX)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button_RectB1)
        Me.Controls.Add(Me.Button_RectB4)
        Me.Controls.Add(Me.Button_RectB3)
        Me.Controls.Add(Me.Button_RectB2)
        Me.Controls.Add(Me.Button_RectA1)
        Me.Controls.Add(Me.Button_RectA4)
        Me.Controls.Add(Me.Button_RectA3)
        Me.Controls.Add(Me.Button_RectA2)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Button_Square1)
        Me.Controls.Add(Me.Button_Square4)
        Me.Controls.Add(Me.Button_Square3)
        Me.Controls.Add(Me.Button_Square2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button_Smallest)
        Me.Controls.Add(Me.Button_Tiny)
        Me.Controls.Add(Me.Button_Strip3)
        Me.Controls.Add(Me.Button_Strip2)
        Me.Controls.Add(Me.Button_Strip1)
        Me.Controls.Add(Me.Button_BottomRight)
        Me.Controls.Add(Me.Button_BottomLeft)
        Me.Controls.Add(Me.Button_TopRight)
        Me.Controls.Add(Me.Button_TopLeft)
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents Label_FormX As Label
    Friend WithEvents Label_FormY As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label_FormHeight As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label_FormWidth As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Button_Reset As Button
    Friend WithEvents Button_Smallest As Button
    Friend WithEvents Button_TopLeft As Button
    Friend WithEvents Button_TopRight As Button
    Friend WithEvents Button_BottomLeft As Button
    Friend WithEvents Button_BottomRight As Button
    Friend WithEvents Button_Strip1 As Button
    Friend WithEvents Button_Strip2 As Button
    Friend WithEvents Button_Strip3 As Button
    Friend WithEvents Button_Tiny As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button_Square1 As Button
    Friend WithEvents Button_Square4 As Button
    Friend WithEvents Button_Square3 As Button
    Friend WithEvents Button_Square2 As Button
    Friend WithEvents Button_DisplayInfo As Button
    Friend WithEvents Button_RectA1 As Button
    Friend WithEvents Button_RectA4 As Button
    Friend WithEvents Button_RectA3 As Button
    Friend WithEvents Button_RectA2 As Button
    Friend WithEvents Button_RectB1 As Button
    Friend WithEvents Button_RectB4 As Button
    Friend WithEvents Button_RectB3 As Button
    Friend WithEvents Button_RectB2 As Button
    Friend WithEvents TextBox_CustomX As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox_CustomY As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox_CustomHeight As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox_CustomWidth As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Button_CustomPositionGo As Button
    Friend WithEvents TextBox_Margin As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents CheckBox_Animation As CheckBox
    Friend WithEvents TextBox_Interval As TextBox
    Friend WithEvents Label_Interval As Label
    Friend WithEvents TextBox_Duration As TextBox
    Friend WithEvents Label_Duration As Label
    Friend WithEvents ComboBox_EasingFunctions As ComboBox
    Friend WithEvents Label_Easing As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button_DoubleStrip1 As Button
    Friend WithEvents Button_DoubleStrip4 As Button
    Friend WithEvents Button_DoubleStrip3 As Button
    Friend WithEvents Button_DoubleStrip2 As Button
    Friend WithEvents Button_TripleStrip1 As Button
    Friend WithEvents Button_About As Button
    Friend WithEvents TextBox_Opacity As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Button_Fade1 As Button
    Friend WithEvents Button_Fade4 As Button
    Friend WithEvents Button_Fade3 As Button
    Friend WithEvents Button_Fade2 As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents TextBox_VBCode As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Button_Size1 As Button
    Friend WithEvents Button_Size4 As Button
    Friend WithEvents Button_Size3 As Button
    Friend WithEvents Button_Size2 As Button
    Friend WithEvents Button_Callback As Button
    Friend WithEvents Button_Random As Button
    Friend WithEvents Label_Animating As Label
    Friend WithEvents Button_Dynamic As Button
End Class
